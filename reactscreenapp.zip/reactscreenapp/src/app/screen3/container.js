import React from 'react';
import styled from 'styled-components';
import TableGrid from './components/table';
import ChanelGrid from './components/chanelgrid';

const LeftSection = styled.div`
    width: calc(100% - 420px);
    display: inline-block;
    vertical-align: top;
`;
const RightSection = styled.div`
    width: 190px;
    margin-left: 10px;
    display: inline-block;
    vertical-align: top;
`;

const TableSection = styled.div`
    border: 3px solid #000;
    box-sizing: border-box;
    width: 100%;
`;

const ScrollSection = styled.div`
    height: 480px;
    overflow: auto;
    padding-top: 5px;
`;
function Container() {
  return (
    <div className="container-fluid">
        <LeftSection>
            <h2>Moncoton</h2>
            <TableSection className="table-section">
                <ScrollSection>
                    <TableGrid />
                </ScrollSection>
            </TableSection>
        </LeftSection>
      <RightSection>
      <ChanelGrid />
      </RightSection>
    </div>
  );
}

export default Container;