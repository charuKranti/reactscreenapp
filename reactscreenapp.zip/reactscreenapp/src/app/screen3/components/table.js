import React from 'react';
import styled from 'styled-components';

class TableGrid extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            tableData:[
                {"description":"ST XX News at 06","starttime":"18:00:00:00","endtime":"18:00:00:00","isSuccess":true},
                {"description":"Comercial pepsi","starttime":"18:30:00:00","endtime":"18:20:00:00","isSuccess":false},
                {"description":"Comercial pepsi","starttime":"18:30:00:00","endtime":"18:20:00:00","isSuccess":false},
                {"description":"Comercial pepsi","starttime":"18:30:00:00","endtime":"18:20:00:00","isSuccess":false},
                {"description":"Comercial pepsi","starttime":"18:30:00:00","endtime":"18:20:00:00","isSuccess":false},
                {"description":"Comercial pepsi","starttime":"18:30:00:00","endtime":"18:20:00:00","isSuccess":false},
                {"description":"Comercial pepsi","starttime":"18:30:00:00","endtime":"18:20:00:00","isSuccess":false},
                {"description":"Comercial pepsi","starttime":"18:30:00:00","endtime":"18:20:00:00","isSuccess":false},
                {"description":"Comercial pepsi","starttime":"18:30:00:00","endtime":"18:20:00:00","isSuccess":false},
                {"description":"Comercial pepsi","starttime":"18:30:00:00","endtime":"18:20:00:00","isSuccess":false},
            ]
        }
    }
    render(){
        return (
            <table className="table table-borderless">
                <tbody>
                {this.state.tableData.map((item,index)=>
                    <tr key={index} className={item.isSuccess ? "active" : ""}>
                        <td>{item.starttime}</td>
                        <td>{item.description}</td>
                        <td>{item.endtime}</td>
                    </tr>
                )}
                  
                </tbody>
          </table>
        )
    }
}

export default TableGrid;