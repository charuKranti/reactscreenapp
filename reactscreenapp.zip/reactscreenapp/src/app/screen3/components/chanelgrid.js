import React from 'react';
import styled from 'styled-components';


class ChanelGrid extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            chanelList:[
                {"description":"ST XX News at 06","isError":true},
                {"description":"ST XX News at 06","isError":false},
                {"description":"ST XX News at 06","isError":false},
                {"description":"ST XX News at 06","isError":false},
                {"description":"ST XX News at 06","isError":true},
                {"description":"ST XX News at 06","isError":false},
                {"description":"ST XX News at 06","isError":false},
                {"description":"ST XX News at 06","isError":false},
                {"description":"ST XX News at 06","isError":false},
            ]
        }
    }
    
    render(){
        return (
            <>
                <label>Control point</label>
                <div >
                    <select>
                        <option>HAL studio</option>
                        <option>chanel 2</option>
                        <option>chanel 3</option>
                        <option>chanel 4</option>
                    </select>
                </div>
            
                <ul className="box-list">
                    {this.state.chanelList.map((item,index)=> 
                        <li key={index} className={item.isError ? "active" : ""}>
                            {item.description}
                        </li>
                    )}
              </ul>
            </>
        )
    }
}

export default ChanelGrid;